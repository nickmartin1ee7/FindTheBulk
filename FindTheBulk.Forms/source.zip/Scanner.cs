﻿using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace FindTheBulk.Forms
{
    public class Scanner
    {
        private DirectoryInfo _directory;
        private bool _recurseDirectories;

        public Scanner(DirectoryInfo directory, bool recurseDirectories)
        {
            _directory = directory;
            _recurseDirectories = recurseDirectories;
        }

        public void OnFileFound(FileFoundEventArgs e)
        {
            var handler = FileFound;
            handler?.Invoke(this, e);
        }

        public EventHandler<FileFoundEventArgs> FileFound;

        public void Start()
        {
            var searchOption = _recurseDirectories ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly;

            FileInfo[] files;

            try
            {
                files = _directory.GetFiles("*", searchOption);
            }
            catch (UnauthorizedAccessException e)
            {
                MessageBox.Show(e.Message, "Unauthorized", MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw;
            }


            var sortedFiles = files.OrderByDescending(f => f.Length).ToList();

            foreach (var file in sortedFiles)
            {
                OnFileFound(new FileFoundEventArgs
                {
                    File = file
                });
            }
        }
    }

    public class FileFoundEventArgs : EventArgs
    {
        public FileInfo File { get; set; }
    }
}
