﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FindTheBulk.Forms
{
    public partial class Form2 : Form
    {
        private Form2ViewModel _viewModel;
        private Scanner _scanner;

        public Form2()
        {
            InitializeComponent();
            _viewModel = new Form2ViewModel
            {
                Files = new List<FileInfo>()
            };
            _scanner = new Scanner(Form1.ViewModel.RootDirectory, Form1.ViewModel.RecurseDirectories);
            _scanner.FileFound += ScannerFileFound;
            Task.Run(() => _scanner.Start());
        }

        private void ScannerFileFound(object sender, FileFoundEventArgs e)
        {
            _viewModel.Files.Add(e.File);

            Invoke(new MethodInvoker(delegate
            {
                itemListBox.Items.Add($"{e.File.Name} ({GetFileSizeString(e.File.Length)})");
            }));
        }

        private string GetFileSizeString(long fileLength)
        {
            var loops = 0;

            while (fileLength > 1024)
            {
                loops++;
                fileLength /= 1024;
            }


            var unit = string.Empty;
            switch (loops)
            {
                case 0:
                    unit = "Bytes";
                    break;
                case 1:
                    unit = "KB";
                    break;
                case 2:
                    unit = "MB";
                    break;
                case 3:
                    unit = "GB";
                    break;
                case 4:
                    unit = "TB";
                    break;
                case 5:
                    unit = "PB";
                    break;
                default:
                    break;
            }

            return $"{fileLength} {unit}";
        }

        private void itemListBox_SelectedValueChanged(object sender, EventArgs e)
        {
            var targetFile = _viewModel.Files[itemListBox.SelectedIndex];
            var result = MessageBox.Show(targetFile.PrintProperties(),
                "File Details - Open directory containing file?",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Information,
                MessageBoxDefaultButton.Button2);

            if (result == DialogResult.Yes)
                Process.Start(targetFile.DirectoryName);
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            Owner.Dispose();
        }
    }
}
