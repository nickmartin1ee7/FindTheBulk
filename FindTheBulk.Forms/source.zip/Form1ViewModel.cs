﻿using System.IO;

namespace FindTheBulk.Forms
{
    public class Form1ViewModel
    {
        public DirectoryInfo RootDirectory { get; set; }
        public bool RecurseDirectories { get; set; }
    }
}
