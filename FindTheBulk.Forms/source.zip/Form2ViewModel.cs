﻿using System.Collections.Generic;
using System.IO;

namespace FindTheBulk.Forms
{
    public class Form2ViewModel
    {
        public List<FileInfo> Files { get; set; }
    }
}
